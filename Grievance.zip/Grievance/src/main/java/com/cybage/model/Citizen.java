package com.cybage.model;

public class Citizen
{
	private String citizenid;
	private String name; 
	private String username;
	private String password;
	private String address;
	private String contact;
	private String role;
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getCitizenid() {
		return citizenid;
	}
	public void setCitizenid(String citizenid) {
		this.citizenid = citizenid;
	}
	
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name =name;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	@Override
	public String toString() {
		return "Citizen [citizenid=" + citizenid + ", name=" + name + ", username=" + username + ", password="
				+ password + ", address=" + address + ", contact=" + contact + ", role=" + role + "]";
	}
	

}


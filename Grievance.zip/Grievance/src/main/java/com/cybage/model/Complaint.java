package com.cybage.model;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;

public class Complaint {
	private String compId;
	private String citizenId;
	private String citizenName;
	private String deptId;
	private String deptName;
	private String username;
	private String contactNo;
	private String description;
	private String status;
	private String remark;
	private String file;
	private LocalDate date;
	private LocalDateTime datetime;

	public Complaint() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Complaint(String compId, String citizenId, String deptId, String description, String status,
			String remark, String file, LocalDate date) {
		super();
		this.compId = compId;
		this.citizenId = citizenId;
		this.deptId = deptId;
		this.description = description;
		this.status = status;
		this.remark = remark;
		this.file = file;
		this.date = date;
	}


	public Complaint( String compId, String status, String remark, String citizenName, LocalDate date) {
		super();

		this.compId = compId;
		this.status = status;
		this.remark = remark;
		this.citizenName = citizenName;
		this.date = date;
	}

	public Complaint(String compId, String deptId, String description, String status, String file, LocalDate date) {
		super();
		this.compId = compId;
		this.deptId = deptId;
		this.description = description;
		this.status = status;
		this.file = file;
		this.date = date;
	}
	public Complaint(String compId, String citizenName,String deptName, String description, String status, String file, LocalDate date ) {
		super();
		this.compId=compId;
		this.citizenName=citizenName;
		this.deptName=deptName;
		this.description=description;
		this.status=status;
		this.file = file;
		this.date=date;

	}


	public Complaint(String compId, LocalDateTime dateTime) {
		super();
		this.compId = compId;
		this.datetime = dateTime;
	}

	public Complaint(String compId, String citizenName, String deptName, String description, String status, String remark) {
		this.compId = compId;
		this.citizenName = citizenName;
		this.deptName = deptName;
		this.description = description;
		this.status = status;
		this.remark = remark;
	}

	//department
	public Complaint(String compId,String name,String contactNo, String description,
			String file,String status , String deptName) {
		super();
		this.compId = compId;
		this.citizenName = name;
		this.contactNo = contactNo;
		this.description = description;
		this.deptName = deptName;
		this.file = file;
		this.status=status;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getCompId() {
		return compId;
	}
	public void setCompId(String compId) {
		this.compId = compId;
	}
	public String getCitizenId() {
		return citizenId;
	}
	public void setCitizenId(String citizenId) {
		this.citizenId = citizenId;
	}
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getCitizenName() {
		return citizenName;
	}
	public void setCitizenName(String citizenName) {
		this.citizenName = citizenName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public LocalDateTime getDatetime() {
		return datetime;
	}
	public void setDatetime(LocalDateTime datetime) {
		this.datetime = datetime;
	}
	@Override
	public String toString() {
		return "Complaint [compId=" + compId + ", citizenId=" + citizenId + ", citizenName=" + citizenName + ", deptId="
				+ deptId + ", deptName=" + deptName + ", description=" + description + ", status=" + status
				+ ", remark=" + remark + ", file=" + file + ", date=" + date + "]";
	}


}

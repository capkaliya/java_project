package com.cybage.controller;

import java.io.IOException;
import java.security.Principal;

import javax.servlet.ServletException;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@ServletSecurity(
		value = @HttpConstraint(
				rolesAllowed = {"admin", "department", "citizen"}
				)
		)

public class AppController extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Principal principal = request.getUserPrincipal(); 
		System.out.println(principal.getName());
		request.setAttribute("username", principal.getName());
		HttpSession session = request.getSession();
		session.setAttribute("username", principal.getName());
		if(request.isUserInRole("admin")) {
			request.getRequestDispatcher("/admin/admin-home.jsp").forward(request, response);
		}
		if(request.isUserInRole("department")) {
			//request.getRequestDispatcher("/departmentHead/home.jsp").forward(request, response);
			response.sendRedirect("DepartmentHeadController/homePage");
		}
		if(request.isUserInRole("citizen")) {
//			request.getRequestDispatcher("/citizen/citizen-home.jsp").forward(request, response);
			response.sendRedirect("CitizenController/citizenHome");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

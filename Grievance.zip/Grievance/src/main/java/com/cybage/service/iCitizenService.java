package com.cybage.service;

import java.time.LocalDate;
import java.util.List;

import com.cybage.model.Citizen;
import com.cybage.model.Complaint;

public interface iCitizenService {
	
	public int addCitizen(Citizen citizn) throws Exception;

	public int addComplain(Complaint comp) throws Exception ;
	
	public List<Complaint> getStatus(String CitizId) throws Exception;
	
	public int setReminder(String compId) throws Exception;
	
	public int reOpen(String compId) throws Exception;

	public String getCitizenId(String username) throws Exception;
		
	public LocalDate getComplainDate(String compId) throws Exception;
	

}

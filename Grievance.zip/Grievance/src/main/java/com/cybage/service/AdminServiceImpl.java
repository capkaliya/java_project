package com.cybage.service;

public class AdminServiceImpl {

}

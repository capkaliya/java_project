package com.cybage.dao;

public class DepartmentHeadDaoImpl {

}

package com.cybage.dao;

public class AdminDaoImpl {

}

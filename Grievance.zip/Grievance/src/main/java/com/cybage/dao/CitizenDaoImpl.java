package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cybage.model.Complain;

public class CitizenDaoImpl {

	public int addComplain(Complain comp) throws Exception {
		String sql = "insert into complain values(?, ?, ?, ?, ?, ?, ?, ?)";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		String deptId = getDeptId(comp.getDeptId());
		ps.setString(1, comp.getCompId());
		ps.setString(2, "Road");
		ps.setString(3, deptId);
		ps.setString(4, comp.getDescription());
		ps.setString(5, comp.getStatus());
		ps.setString(6, "REMARK");
		ps.setString(7, comp.getFile());
		ps.setDate(8, java.sql.Date.valueOf(comp.getDate()));
		System.out.println("value added");
		return ps.executeUpdate();
	}

	//For getting DeptId
	public String getDeptId(String name) throws Exception{
		String sql = "select deptId from department where deptName = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, name);
		ResultSet rs = ps.executeQuery();
		String  deptId = null;
		if(rs.next()) {
			deptId = rs.getString(1);
		}
		return deptId;
	}

	//For getting complaint status

	public List<Complain> getStatus(String citizId) throws Exception{
		String sql = "SELECT complain.compId, complain.status, complain.remark,complain.date, "
				+ "citizen.name FROM complain "
				+ "INNER JOIN citizen ON complain.citizenId=citizen.citizenId";

		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<Complain> status = new ArrayList<>();
		while(rs.next()) {
			status.add(new Complain(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(5),rs.getDate(4).toLocalDate()));
		}
		return status;
	}
	public int setReminder(Complain remind)  throws Exception{
		String sql = "insert into reminder (complainId,date) values(?, ?)";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);		
//		ps.setString(1, "1");
		ps.setString(1, remind.getCompId());
		ps.setTimestamp(2, java.sql.Timestamp.valueOf(remind.getDateTime()));
		return ps.executeUpdate();
	}
	
	public int reOpen(String compId)  throws Exception{
		String sql = "update complain set status = ? where compId = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);		
		ps.setString(1, "Open");
		ps.setString(2, compId);
		return ps.executeUpdate();
	}


}

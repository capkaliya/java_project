package com.cybage.service;

public class DepartmentHeadServiceImpl {

}

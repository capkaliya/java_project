package com.cybage.service;

import java.util.List;

import com.cybage.model.Complain;

public interface iCitizenService {
	public int addComplain(Complain comp) throws Exception ;
	
	public List<Complain> getStatus(String CitizId) throws Exception;
	
	public int setReminder(String compId) throws Exception;
		
	
	

}

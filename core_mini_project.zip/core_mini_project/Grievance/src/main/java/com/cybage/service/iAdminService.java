package com.cybage.service;

public interface iAdminService {

}

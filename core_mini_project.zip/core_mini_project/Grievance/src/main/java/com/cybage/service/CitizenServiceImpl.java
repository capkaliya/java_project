package com.cybage.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.cybage.dao.CitizenDaoImpl;
import com.cybage.model.Complain;

public class CitizenServiceImpl implements iCitizenService {
	
	private String generateCompID(){
		return "C"+ Math.round(Math.random()*999999999);
	}
	
	private LocalDateTime dateTime() {
		 LocalDateTime today = LocalDateTime.now();
		 return today;
	}
	CitizenDaoImpl cdao = new CitizenDaoImpl();
	
	@Override
	public int addComplain(Complain comp) throws Exception {
		LocalDate today = LocalDate.now();
		Complain compln = new Complain(generateCompID(), comp.getDeptId(), comp.getDescription(), comp.getStatus(), comp.getFile(), today);
		System.out.println("in service");
		cdao.addComplain(compln);
		return 0;
	}
	
	@Override
	public List<Complain> getStatus(String CitizId) throws Exception {
		
		return cdao.getStatus(CitizId);
	}
	
	@Override
	public int setReminder(String compId) throws Exception {
		Complain remind = new Complain(compId, dateTime());
		return cdao.setReminder(remind);
	}

}
